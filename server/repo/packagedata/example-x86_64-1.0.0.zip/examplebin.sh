#! busybox ash
echo Hello